$(function() {
    $("#loader").show();
});
$(window).load(function() {
    $("#loader").fadeOut(500);
});
